package be.vdab.cultuurhuis.services;

import java.util.Optional;

import be.vdab.cultuurhuis.domain.Klant;
import be.vdab.cultuurhuis.forms.NieuweKlantForm;


public interface KlantService {

    Optional<Klant> findByGebruikersnaam(String gebruikersnaam);

	
	Klant create(NieuweKlantForm klantForm);
	
	
	
	/*
	 List<Klant> findById(long id);
	   
	 boolean gebruikersnaamAlBestaat(String gebruikersnaam);
	
	 boolean klantAlBestaat(long id);
	*/
}
