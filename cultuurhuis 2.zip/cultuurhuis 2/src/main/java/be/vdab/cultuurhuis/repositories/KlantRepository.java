package be.vdab.cultuurhuis.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import be.vdab.cultuurhuis.domain.Klant;

public interface KlantRepository extends JpaRepository<Klant, Long> { 
	
	
Optional<Klant> findByGebruikersnaam(String gebruikersnaam);

List<Klant> findById(long id);


}
