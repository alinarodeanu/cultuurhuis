package be.vdab.cultuurhuis.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.PositiveOrZero;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "voorstellingen")
public class Voorstelling implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@NotBlank
	private String titel;

	@NotBlank
	private String uitvoerders;

	@NotNull
	@DateTimeFormat(style = "S-")
	private LocalDateTime datum;

	@NotNull
	@Positive
	private BigDecimal prijs;

	@PositiveOrZero
	private long vrijeplaatsen;

	@Version
	private long versie;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "genreid")
	@NotNull
	private Genre genre;

	@OneToMany(mappedBy = "voorstelling")
	private Set<Reservatie> reservaties;

	public Set<Reservatie> getReservaties() {
		return Collections.unmodifiableSet(reservaties);
	}

	public long getId() {
		return id;
	}

	public String getTitel() {
		return titel;
	}

	public String getUitvoerders() {
		return uitvoerders;
	}

	public LocalDateTime getDatum() {
		return datum;
	}

	public BigDecimal getPrijs() {
		return prijs;
	}

	public long getVrijeplaatsen() {
		return vrijeplaatsen;
	}

	public Genre getGenre() {
		return genre;
	}

	public void setVrijeplaatsen(Long vrijeplaatsen) {
		this.vrijeplaatsen = vrijeplaatsen;
	}

	public void verminderenPlaatsen(long aantal) {
		this.vrijeplaatsen -= aantal;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((titel == null) ? 0 : titel.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Voorstelling))
			return false;
		Voorstelling other = (Voorstelling) obj;
		if (titel == null) {
			if (other.titel != null)
				return false;
		} else if (!titel.equals(other.titel))
			return false;
		return true;
	}

}
