package be.vdab.cultuurhuis.forms;

import java.util.List;

import javax.validation.constraints.NotNull;

public class VerwijderVoorstellingForm {

	@NotNull
	private List<Long> voorstellingIDs;

	public List<Long> getVoorstellingIDs() {
		return voorstellingIDs;
	}

	public void setVoorstellingIDs(List<Long> voorstellingIDs) {
		this.voorstellingIDs = voorstellingIDs;
	}
	
}
