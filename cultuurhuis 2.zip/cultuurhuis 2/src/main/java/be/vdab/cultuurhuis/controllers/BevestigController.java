package be.vdab.cultuurhuis.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;



@Controller
@RequestMapping("bevestigstap1")
class BevestigController {

	
	@GetMapping
	ModelAndView bevestig() {
		return new ModelAndView("bevestigstap1");
	}
}

	
	