package be.vdab.cultuurhuis.services;


import java.util.List;
import java.util.Map;

import be.vdab.cultuurhuis.domain.Klant;
import be.vdab.cultuurhuis.domain.Reservatie;
import be.vdab.cultuurhuis.forms.ReserverenForm;

public interface ReservatieService {

	
	
	// List<List<Reservatie>> createAll(List<ReserverenForm> reservatiesForm, Klant klant);
	
	Map<String,List<Reservatie>> createAll(List<ReserverenForm> reserverenForms, Klant klant);
	
	
	

	//void createReservaties(List<Reservatie> reservaties, String gebruikersnaam);
	
	//void create(Reservatie reservatie);

}