package be.vdab.cultuurhuis.exceptions;

public class ReservatieException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	
	public ReservatieException(String message) {
		super(message);
	}
	
}
