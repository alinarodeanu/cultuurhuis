package be.vdab.cultuurhuis.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import be.vdab.cultuurhuis.domain.Klant;
import be.vdab.cultuurhuis.domain.Reservatie;
import be.vdab.cultuurhuis.forms.ReserverenForm;
import be.vdab.cultuurhuis.repositories.ReservatieRepository;

@Service
@Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
class DefaultReservatieService implements ReservatieService {

	private final ReservatieRepository reservatieRepository;
	private final VoorstellingService voorstellingService;

	DefaultReservatieService(ReservatieRepository reservatieRepository, VoorstellingService voorstellingService) {
		this.reservatieRepository = reservatieRepository;
		this.voorstellingService = voorstellingService;
	}

	@Override
	@Transactional(readOnly = false, isolation = Isolation.READ_COMMITTED)
	public Map<String, List<Reservatie>> createAll(List<ReserverenForm> reserverenForms, Klant klant) {
		// public List<List<Reservatie>> createAll(List<ReserverenForm> reserverenForms,
		// Klant klant) {

		List<Reservatie> reservaties = convertFormToReservatie(reserverenForms, klant);

		Map<String, List<Reservatie>> gelukteEnMislukteReservaties = new HashMap<>();

		List<Reservatie> mislukteReservaties = new ArrayList<>();
		List<Reservatie> gelukteReservaties = new ArrayList<>();

		for (Reservatie reservatie : reservaties) {

			if (reservatie.getVoorstelling().getVrijeplaatsen() >= reservatie.getPlaatsen()) {

				reservatie.getVoorstelling().verminderenPlaatsen(reservatie.getPlaatsen());
				voorstellingService.update(reservatie.getVoorstelling());
				reservatieRepository.save(reservatie);
				gelukteReservaties.add(reservatie);
			} else {
				mislukteReservaties.add(reservatie);
			}
		}

		// List<List<Reservatie>> gelukteEnMislukteReservaties = new ArrayList<>();
		// gelukteEnMislukteReservaties.add(gelukteReservaties);
		// gelukteEnMislukteReservaties.add(mislukteReservaties);

		gelukteEnMislukteReservaties.put("gelukt", gelukteReservaties);
		gelukteEnMislukteReservaties.put("mislukt", mislukteReservaties);

		return gelukteEnMislukteReservaties;
	}

	/*
	 * private List<Reservatie> convertFormToReservatie(List<ReserverenForm> forms,
	 * Klant klant){ List<Reservatie> reservaties = new ArrayList<>();
	 * 
	 * for (ReserverenForm form : forms) { reservaties.add(new Reservatie(klant,
	 * voorstellingService.findById(form.getVoorstelling().getId()).get(0)
	 * ,form.getPlaatsen())); } return reservaties; }
	 */

	private List<Reservatie> convertFormToReservatie(List<ReserverenForm> forms, Klant klant) {
		List<Reservatie> reservaties = new ArrayList<>();

		for (ReserverenForm form : forms) {
			reservaties.add(new Reservatie(klant, voorstellingService.findById(form.getVoorstelling().getId()).get(),
					form.getPlaatsen()));
		}
		return reservaties;
	}

}





/*
 * @Override
 * 
 * @Transactional(readOnly = false, isolation = Isolation.READ_COMMITTED) public
 * void create(Reservatie reservatie) { reservatieRepository.save(reservatie); }
 */

/*
 * @Transactional(readOnly = false)
 * 
 * @Override public void createReservaties(List<Reservatie> reservaties, String
 * gebruikersnaam) { List<Klant> klanten =
 * klantService.findByGebruikersnaam(gebruikersnaam); for (Klant klant :
 * klanten) {
 * 
 * for (Reservatie reservatie : reservaties) { if (klant.getId() != 0) { // if
 * (voorstellingService.update(reservatie.getVoorstelling().getId()) == 1) {
 * reservatie.getKlant().getId(); //reservatieService.create(reservatie); if
 * (reservatie.getId() != 0) { System.out.println(reservatie.getId() +
 * " is gelukt"); } else { System.out.println("reservatie voor " +
 * reservatie.getVoorstelling().getId() + " is mislukt"); } } else {
 * System.out.println("klant niet gevonden"); } } } }
 */