package be.vdab.cultuurhuis.forms;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import be.vdab.cultuurhuis.constraints.ReservatieConstraint;
import be.vdab.cultuurhuis.domain.Voorstelling;

@ReservatieConstraint
public class ReserverenForm {
	
	
	@NotNull
    private Voorstelling voorstelling;
	
    @Positive
    @Min(1)
    private long plaatsen;

    protected ReserverenForm() {}

    public ReserverenForm(Voorstelling voorstelling, @Positive long plaatsen) {
        this.voorstelling = voorstelling;
        this.plaatsen = plaatsen;
    }

    public Voorstelling getVoorstelling() {
        return voorstelling;
    }

    public void setVoorstelling(Voorstelling voorstelling) {
        this.voorstelling = voorstelling;
    }

    public long getPlaatsen() {
        return plaatsen;
    }

    public void setPlaatsen(long plaatsen) {
        this.plaatsen = plaatsen;
    }

	
}
