package be.vdab.cultuurhuis.domain;

import java.io.Serializable;
import java.util.Collections;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;



@Entity
@Table(name = "genres")
public class Genre implements Serializable {

	private static final long serialVersionUID = 1L;

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@NotBlank
	private String naam;
	
	@OneToMany(mappedBy = "genre")
	private Set<Voorstelling> voorstellingen;

	public Set<Voorstelling> getVoorstellingen() {
		return Collections.unmodifiableSet(voorstellingen);
	}
	

	public long getId() {
		return id;
	}

	public String getNaam() {
		return naam;
	}
	
	
	
}