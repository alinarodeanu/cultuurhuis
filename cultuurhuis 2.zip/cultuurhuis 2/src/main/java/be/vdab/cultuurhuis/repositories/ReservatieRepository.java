package be.vdab.cultuurhuis.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import be.vdab.cultuurhuis.domain.Reservatie;

public interface ReservatieRepository extends JpaRepository<Reservatie, Long> {

}