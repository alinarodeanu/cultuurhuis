package be.vdab.cultuurhuis.sessions;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;

import java.util.List;

import java.util.stream.Collectors;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import be.vdab.cultuurhuis.domain.Voorstelling;
import be.vdab.cultuurhuis.forms.ReserverenForm;

@Component
@SessionScope
public class Mandje implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<ReserverenForm> reservaties = new ArrayList<>();

	public void addReservatie(ReserverenForm reserverenForm) {
		if (!reservaties.contains(reserverenForm)) {
			reservaties.add(reserverenForm);
		}
	}

	public List<ReserverenForm> getAlleReservaties() {
		return Collections.unmodifiableList(reservaties);
	}

	public ReserverenForm reservatieNieuw(Voorstelling voorstelling) {
		List<ReserverenForm> res = reservaties.stream()
				.filter(reservatie -> reservatie.getVoorstelling().equals(voorstelling)).collect(Collectors.toList());
		if (res.size() == 1) {
			return res.get(0);
		} else {
			return new ReserverenForm(voorstelling, 0);
		}
	}

	public void deleteReservaties(List<Voorstelling> voorstellingToDelete) {

		List<ReserverenForm> reservatiesToDelete = new ArrayList<>();

		for (ReserverenForm reservatie : reservaties) {
			if (voorstellingToDelete.contains(reservatie.getVoorstelling())) {
				reservatiesToDelete.add(reservatie);
			}
		}
		for (ReserverenForm reservatie : reservatiesToDelete) {
			reservaties.remove(reservatie);
		}
	}

	public BigDecimal getTotaalTeBetalen() {
		BigDecimal result = BigDecimal.ZERO;
		for (ReserverenForm reservatie : reservaties) {
			result = result.add(
					reservatie.getVoorstelling().getPrijs().multiply(BigDecimal.valueOf(reservatie.getPlaatsen())));

		}
		return result;
	}

	public void leegMandje() {
		this.reservaties = new ArrayList<>();
	}

	public int getMandjeSize() {
		return this.reservaties.size();
	}

}

/*
 * //@Min(1) //private final Map<Long, PlaatsenEnPrijs> idPlaatsen = new
 * HashMap<>();
 * 
 * 
 * //private final Map<Voorstelling, PlaatsenEnPrijs> voorstellingPlaatsen = new
 * HashMap<>();
 * 
 * public void add(long id, long plaatsen, BigDecimal prijs) {
 * idPlaatsen.put(id, new PlaatsenEnPrijs(plaatsen, prijs));
 * 
 * }
 * 
 * public boolean containsId(long id) { return idPlaatsen.containsKey(id); }
 * 
 * 
 * public boolean isGevuld() { return !idPlaatsen.isEmpty(); }
 * 
 * public boolean isLeeg() { return idPlaatsen.isEmpty(); }
 * 
 * 
 * public Map<Long, PlaatsenEnPrijs> getIdPlaatsen() { return idPlaatsen; }
 * 
 * 
 * public void verwijderVoorstellingen(Iterable<Long> ids ) { for (long id: ids)
 * { idPlaatsen.remove(id); } }
 */
