package be.vdab.cultuurhuis.domain;


import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;




@Entity
@Table(name = "reservaties")
public class Reservatie implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private long id;
	

	 
	@NotNull
	@ManyToOne(optional = false, fetch = FetchType.LAZY) 
	@JoinColumn(name = "klantid")
	private Klant klant;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false) 
	@JoinColumn(name = "voorstellingid")
	private Voorstelling voorstelling;
	

    @Positive
	private long plaatsen;

	
	
	protected Reservatie() {
		super();
	}


	public Reservatie(@NotNull Klant klant, Voorstelling voorstelling, long plaatsen) {
		
		this.klant = klant;
		this.voorstelling = voorstelling;
		this.plaatsen = plaatsen;
	}




	public Reservatie(Voorstelling voorstelling, long plaatsen) {
		this.voorstelling = voorstelling;
		this.plaatsen = plaatsen;
	}


	public Klant getKlant() {
		return klant;
	}


	public long getId() {
		return id;
	}


	public Voorstelling getVoorstelling() {
		return voorstelling;
	}


	public long getPlaatsen() {
		return plaatsen;
	}


	public void setPlaatsen(long plaatsen) {
		this.plaatsen = plaatsen;
	}
	
	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Reservatie that = (Reservatie) o;
        return Objects.equals(klant, that.klant);
    }

    @Override
    public int hashCode() {
        return Objects.hash(klant);
    }
	
	
}
