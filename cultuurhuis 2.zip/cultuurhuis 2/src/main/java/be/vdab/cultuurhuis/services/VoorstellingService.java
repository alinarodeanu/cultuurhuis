package be.vdab.cultuurhuis.services;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import be.vdab.cultuurhuis.domain.Voorstelling;

public interface VoorstellingService {
	
	
List<Voorstelling> findByGenreId(long genreid);

Optional<Voorstelling> findById(long id);

Iterable<Voorstelling> findAllById(Set<Long> voorstellingen);

void update(Voorstelling voorstelling);

List<Voorstelling> findByIds(List<Long> ids);



//List<Voorstelling> findById(long id);

//Optional<Voorstelling> voorstellingNow(long genreid);

}

