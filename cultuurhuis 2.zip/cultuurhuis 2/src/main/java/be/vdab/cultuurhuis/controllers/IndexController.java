package be.vdab.cultuurhuis.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import be.vdab.cultuurhuis.services.GenreService;
import be.vdab.cultuurhuis.services.VoorstellingService;
import be.vdab.cultuurhuis.sessions.Mandje;

@Controller
@RequestMapping("/")
class IndexController {

	private final GenreService genreService;
	private final VoorstellingService voorstellingService;
	private final Mandje mandje;
	

	IndexController(GenreService genreService, VoorstellingService voorstellingService, Mandje mandje) {
		this.genreService = genreService;
		this.voorstellingService = voorstellingService;
		this.mandje = mandje;
	
	}

	@GetMapping
	public ModelAndView index() {
		return new ModelAndView("index", "genres", genreService.findAll())
				.addObject("mandjesize", mandje.getMandjeSize());
	}

	@GetMapping("genres/{genreid}")
	public ModelAndView genreVoorstellingen(@PathVariable long genreid) {

		ModelAndView modelAndView = new ModelAndView("index");

		modelAndView.addObject("genres", genreService.findAll());

		modelAndView.addObject("voorstellingenperid", voorstellingService.findByGenreId(genreid))
		.addObject("mandjesize", mandje.getMandjeSize());
		
		return modelAndView;

	}
	

}





/*@GetMapping("voorstellingdetail/{id}")
public ModelAndView voorstellingDetail(@PathVariable long id) {
	
	ReserverenForm reserverenForm = new ReserverenForm();
	if(mandje.containsId(id)) {
		reserverenForm.setPlaatsen(mandje.getIdPlaatsen().get(id).getPlaatsen());
	}

	ModelAndView modelAndView = new ModelAndView("voorstellingdetail"); 	
	//voorstellingService.findById(id).forEach(voorstelling -> 
	  //  modelAndView.addObject("voorstellingids", voorstelling));
	modelAndView.addObject("voorstellingids", voorstellingService.findById(id));
	modelAndView.addObject("vrijeplaatsen", voorstellingService.findById(id).get(0).getVrijeplaatsen());
	//modelAndView.addObject("mandjeIsLeeg", mandje.isLeeg());
	modelAndView.addObject(reserverenForm);
	
	return modelAndView;
}

@PostMapping("voorstellingdetail/opslaan")
ModelAndView opslaanReservatie(Model model, @Valid @ModelAttribute("voorstellingdetail") ReserverenForm reservatie, BindingResult result, Errors errors){
    if (result.hasErrors()){
    	return new ModelAndView("voorstellingdetail").addObject("mandjesize", mandje.getMandjeSize());
        
    }
    mandje.addReservatie(reservatie);

    return new ModelAndView("redirect:/").addObject("mandjesize", mandje.getMandjeSize());
}*/
	
	

	

	
	