package be.vdab.cultuurhuis.services;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import be.vdab.cultuurhuis.domain.Voorstelling;
import be.vdab.cultuurhuis.repositories.VoorstellingRepository;

@Service
@Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
class DefaultVoorstellingService implements VoorstellingService {

	private final VoorstellingRepository voorstellingRepository;

	DefaultVoorstellingService(VoorstellingRepository voorstellingRepository) {
		this.voorstellingRepository = voorstellingRepository;
	}

	@Override
	public List<Voorstelling> findByGenreId(long genreid) {
		return voorstellingRepository.findByGenreIdOrderByDatumDesc(genreid);
	}

	@Override
	public Optional<Voorstelling> findById(long id) {
		return voorstellingRepository.findById(id);
	}

	@Override
	@Transactional(readOnly = false, isolation = Isolation.READ_COMMITTED)
	public void update(Voorstelling voorstelling) {
		voorstellingRepository.save(voorstelling);
	}

	@Override
	public Iterable<Voorstelling> findAllById(Set<Long> voorstellingen) {
		return voorstellingRepository.findAllById(voorstellingen);
	}

	@Override
	public List<Voorstelling> findByIds(List<Long> ids) {
		return voorstellingRepository.findAllById(ids);
	}

}

/*
 * @Override
 * 
 * @Transactional(readOnly = false, isolation = Isolation.READ_COMMITTED) public
 * Optional<Voorstelling> voorstellingNow(long genreid) { Optional<Voorstelling>
 * voorstelling1 = voorstellingRepository.findAllByGenreIdOrderByDatum(genreid);
 * if (voorstelling1.isPresent()) {
 * voorstelling1.get().localeDateTimeNowVoorstellingen(); } else { throw new
 * VoorstellingNotFoundException(); } return voorstelling1; }
 */