package be.vdab.cultuurhuis.exceptions;

public class KlantAlBestaatException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

}
