package be.vdab.cultuurhuis.controllers;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import be.vdab.cultuurhuis.domain.Reservatie;
import be.vdab.cultuurhuis.services.KlantService;
import be.vdab.cultuurhuis.services.ReservatieService;
import be.vdab.cultuurhuis.services.VoorstellingService;
import be.vdab.cultuurhuis.sessions.Mandje;

@Controller
@RequestMapping("mandje")
public class MandjeController {

	private final Mandje mandje;
	private final VoorstellingService voorstellingService;
	private final ReservatieService reservatieService;
	private final KlantService klantService;

	public MandjeController(Mandje mandje, VoorstellingService voorstellingService, ReservatieService reservatieService,
			KlantService klantService) {
		this.mandje = mandje;
		this.voorstellingService = voorstellingService;
		this.reservatieService = reservatieService;
		this.klantService = klantService;
	}

	@GetMapping
	ModelAndView toonMandje() {
		ModelAndView modelAndView = new ModelAndView("mandje");
		modelAndView.addObject("reservaties", mandje.getAlleReservaties());
		modelAndView.addObject("totaalBetalen", mandje.getTotaalTeBetalen());
		modelAndView.addObject("deletelist", new ArrayList<>());
		modelAndView.addObject("mandjesize", mandje.getMandjeSize());
		return modelAndView;
	}

	@PostMapping("/verwijderen")
	ModelAndView verwijderGekozenReservaties(@RequestParam List<Long> deletelist) {

		mandje.deleteReservaties(voorstellingService.findByIds(deletelist));
		return new ModelAndView("redirect:/");
	}

	@GetMapping("/bevestigen")
	ModelAndView bevestigenReservaties(Principal principal) {

		return new ModelAndView("bevestigen", "klant", klantService.findByGebruikersnaam(principal.getName()).get());
	}

	@PostMapping("/opslaan")
	ModelAndView reservatiesOpslaan(Principal principal) {

		if (mandje.getMandjeSize() <= 0) {
			return new ModelAndView("redirect:/500");
		}

		/*
		 * List<List<Reservatie>> gelukteEnMislukteReservatie =
		 * reservatieService.createAll(mandje.getAlleReservaties(),
		 * klantService.findByGebruikersnaam(principal.getName()).get());
		 */

		Map<String, List<Reservatie>> gelukteEnMislukteReservatie = reservatieService
				.createAll(mandje.getAlleReservaties(), klantService.findByGebruikersnaam(principal.getName()).get());

		ModelAndView modelAndView = new ModelAndView("overzicht");
		// modelAndView.addObject("misluktereservaties",
		// gelukteEnMislukteReservatie.get(1));
		// modelAndView.addObject("allereservaties",
		// gelukteEnMislukteReservatie.get(0));

		modelAndView.addObject("misluktereservaties", gelukteEnMislukteReservatie.get("mislukt"));
		modelAndView.addObject("gelukltereservaties", gelukteEnMislukteReservatie.get("gelukt"));

		mandje.leegMandje();

		return modelAndView;
	}

	@GetMapping("/overzicht")
	public ModelAndView toonOverzicht(List<Reservatie> mislukteReservaties, List<Reservatie> gelukteReservaties) {

		ModelAndView modelAndView = new ModelAndView("overzicht");
		modelAndView.addObject("misluktereservaties", mislukteReservaties);
		modelAndView.addObject("geluktereservaties", gelukteReservaties);

		return modelAndView;
	}

}







/*
 * @GetMapping ModelAndView toonMandje() {
 * 
 * if (mandje.isLeeg()) { return new ModelAndView("redirect:/"); } else {
 * 
 * ModelAndView modelAndView = new ModelAndView("mandje");
 * 
 * Map<Long, PlaatsenEnPrijs> voorstellingInMandje = mandje.getIdPlaatsen();
 * 
 * Map<Voorstelling, PlaatsenEnPrijs> teBetalen = new HashMap<>();
 * 
 * voorstellingInMandje.keySet() .forEach(entry ->
 * voorstellingService.findById(entry) .forEach(voorstelling ->
 * teBetalen.put(voorstelling, new PlaatsenEnPrijs(
 * voorstellingInMandje.get(entry).getPlaatsen(), voorstelling.getPrijs()))));
 * 
 * // modelAndView.addObject("bestelbonForm", new //
 * BestelbonForm(0,LocalDateTime.now(),"","",BigDecimal.valueOf(0),0));
 * 
 * modelAndView.addObject(new
 * VerwijderVoorstellingForm()).addObject("mandjeIsLeeg", mandje.isLeeg())
 * .addObject("voorstellingenInMandje", teBetalen) //.addObject("mandje",
 * voorstellingInMandje) .addObject("totaal", teBetalen.entrySet().stream()
 * .map(voorstellingId -> voorstellingId.getValue().getPrijs()
 * .multiply(BigDecimal.valueOf(voorstellingId.getValue().getPlaatsen())))
 * .reduce(BigDecimal.ZERO, (sum, tebetalenrij) -> sum.add(tebetalenrij)));
 * modelAndView.addObject("mandjesize", mandje.getMandjeSize());
 * 
 * return modelAndView; } }
 * 
 * @PostMapping("/verwijderen") ModelAndView verwijderGekozenReservaties(@Valid
 * VerwijderVoorstellingForm verwijderVoorstellingForm, BindingResult
 * bindingResult) { if (bindingResult.hasErrors() ||
 * !verwijderVoorstellingForm.getVoorstellingIDs().stream() .allMatch(id ->
 * mandje.getIdPlaatsen().containsKey(id))) { Map<Long, PlaatsenEnPrijs>
 * voorstellingInMandje = mandje.getIdPlaatsen();
 * 
 * Map<Voorstelling, PlaatsenEnPrijs> teBetalen = new HashMap<>();
 * 
 * voorstellingInMandje.keySet() .forEach(entry ->
 * voorstellingService.findById(entry) .forEach(voorstelling ->
 * teBetalen.put(voorstelling, new PlaatsenEnPrijs(
 * voorstellingInMandje.get(entry).getPlaatsen(), voorstelling.getPrijs()))));
 * 
 * return new ModelAndView("mandje", "voorstellinginmandje",
 * voorstellingInMandje) .addObject("mandjeIsLeeg",
 * mandje.isLeeg()).addObject("mandje", mandje.getIdPlaatsen())
 * .addObject("totaal", teBetalen.entrySet().stream() .map(voorstellingId ->
 * voorstellingId.getValue().getPrijs()
 * .multiply(BigDecimal.valueOf(voorstellingId.getValue().getPlaatsen())))
 * .reduce(BigDecimal.ZERO, (sum, tebetalenrij) -> sum.add(tebetalenrij))); }
 * mandje.verwijderVoorstellingen(verwijderVoorstellingForm.getVoorstellingIDs()
 * ); return new ModelAndView("redirect:/mandje"); //.addObject("mandjeIsLeeg",
 * mandje.isLeeg()); }
 */
