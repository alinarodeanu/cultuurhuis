package be.vdab.cultuurhuis.exceptions;

public class VoorstellingNotFoundException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

}
