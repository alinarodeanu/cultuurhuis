package be.vdab.cultuurhuis.services;

import java.util.Optional;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import be.vdab.cultuurhuis.domain.Adres;
import be.vdab.cultuurhuis.domain.Klant;
import be.vdab.cultuurhuis.exceptions.KlantAlBestaatException;
import be.vdab.cultuurhuis.forms.NieuweKlantForm;
import be.vdab.cultuurhuis.repositories.KlantRepository;

@Service
@Transactional(readOnly = true, isolation = Isolation.READ_COMMITTED)
public class DefaultKlantService implements KlantService {

	private final PasswordEncoder passwordEncoder;

	private final KlantRepository klantRepository;

	public DefaultKlantService(KlantRepository klantRepository, PasswordEncoder passwordEncoder) {
		this.klantRepository = klantRepository;
		this.passwordEncoder = passwordEncoder;
	}

	@Override
	public Optional<Klant> findByGebruikersnaam(String gebruikersnaam) {
		return klantRepository.findByGebruikersnaam(gebruikersnaam);
	}

	@Override
	@Transactional(readOnly = false, isolation = Isolation.READ_COMMITTED)
	public Klant create(NieuweKlantForm klantForm) {
		if (gebruikersnaamAlBestaat(klantForm.getGebruikersnaam())) {
			throw new KlantAlBestaatException();
		}

		klantForm.setPaswoord(passwordEncoder.encode(klantForm.getPaswoord()));

		Klant klant = new Klant(

				klantForm.getVoornaam(), klantForm.getFamilienaam(), new Adres(klantForm.getStraat(),
						klantForm.getHuisNr(), klantForm.getPostcode(), klantForm.getGemeente()),
				klantForm.getGebruikersnaam(), klantForm.getPaswoord());

		return klantRepository.save(klant);

	}

	private boolean gebruikersnaamAlBestaat(String gebruikersnaam) {
		return findByGebruikersnaam(gebruikersnaam).isPresent();
	}

}





/*
 * @Override public List<Klant> findById(long id) { return
 * klantRepository.findById(id); }
 */

/*
 * @Override public boolean gebruikersnaamAlBestaat(String gebruikersnaam) {
 * Boolean gebruikerBestaat = false;
 * 
 * List<Klant> gebruikers =
 * klantRepository.findByGebruikersnaam(gebruikersnaam);
 * 
 * for (Klant gebruiker:gebruikers) {
 * 
 * if (gebruiker.getGebruikersnaam().compareTo(gebruikersnaam) == 0) {
 * gebruikerBestaat = true; }else { gebruikerBestaat = false; } }
 * 
 * return gebruikerBestaat; }
 * 
 * @Override public boolean klantAlBestaat(long id) { Boolean klantBestaat =
 * false;
 * 
 * List<Klant> klanten = klantRepository.findById(id);
 * 
 * for (Klant klant:klanten) {
 * 
 * if (klant.getId() == id) { klantBestaat = true; }else { klantBestaat = false;
 * } }
 * 
 * 
 * return klantBestaat; }
 */
