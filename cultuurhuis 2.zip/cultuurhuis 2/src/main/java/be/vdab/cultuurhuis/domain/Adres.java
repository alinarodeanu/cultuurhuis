package be.vdab.cultuurhuis.domain;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Range;


@Embeddable
public class Adres implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@NotBlank
    private String straat;
	@NotBlank
    private String huisNr;
	@NotBlank
	@Range(min = 1000, max = 9999) 
    private String postcode;
	@NotBlank
    private String gemeente;


	protected Adres() {
		super();
	}


	public Adres(@NotBlank String straat, @NotBlank String huisNr,
			@NotBlank @Range(min = 1000, max = 9999) String postcode, @NotBlank String gemeente) {
		super();
		this.straat = straat;
		this.huisNr = huisNr;
		this.postcode = postcode;
		this.gemeente = gemeente;
	}




	public String getStraat() {
		return straat;
	}

	public String getHuisNr() {
		return huisNr;
	}

	public String getPostcode() {
		return postcode;
	}

	public String getGemeente() {
		return gemeente;
	}

	
	
}

