package be.vdab.cultuurhuis.controllers;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import be.vdab.cultuurhuis.exceptions.KlantAlBestaatException;
import be.vdab.cultuurhuis.forms.NieuweKlantForm;
import be.vdab.cultuurhuis.services.KlantService;



@Controller
@RequestMapping("signup")
public class KlantController {
	
	private final KlantService klantService;
	
	
	public KlantController(KlantService klantService) {
		this.klantService = klantService;
	}

	@GetMapping
	ModelAndView nieuweKlant() {
		return new ModelAndView("signup").addObject("klant", new NieuweKlantForm(null, null, null, null, null, null, null, null, null));
	}

	@PostMapping("/opslaan")
	ModelAndView nieuweKlantMaken(@Valid @ModelAttribute("klant") NieuweKlantForm nieuweKlantForm, BindingResult bindingResult) {
		
		if (bindingResult.hasErrors()) {
			return new ModelAndView("signup");
		}
		try {
		klantService.create(nieuweKlantForm);
		return new ModelAndView("redirect:/bevestigstap1");
				//.addObject("klant", nieuweKlantForm);
		
		}catch (KlantAlBestaatException ex) {
			bindingResult.rejectValue("gebruikersnaam", "Gebruiker Bestaat Al", "Gebruikersnaam bestaat reeds");
			return new ModelAndView("signup");
		}
	}

	/*@InitBinder
	void initBinderNieuweKlantForm(DataBinder dataBinder) {
		dataBinder.initDirectFieldAccess();
	}*/

	
}
