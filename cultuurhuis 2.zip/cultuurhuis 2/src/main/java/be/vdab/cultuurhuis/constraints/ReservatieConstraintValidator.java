package be.vdab.cultuurhuis.constraints;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import be.vdab.cultuurhuis.forms.ReserverenForm;


public class ReservatieConstraintValidator implements ConstraintValidator<ReservatieConstraint, ReserverenForm> {

    @Override
    public void initialize(ReservatieConstraint constraintAnnotation) {
    }

    @Override
    public boolean isValid(ReserverenForm reservatie, ConstraintValidatorContext constraintValidatorContext) {
        return reservatie.getPlaatsen() <= reservatie.getVoorstelling().getVrijeplaatsen();
    }
}