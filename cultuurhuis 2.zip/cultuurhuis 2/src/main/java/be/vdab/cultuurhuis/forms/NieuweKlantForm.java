package be.vdab.cultuurhuis.forms;

import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Range;

import be.vdab.cultuurhuis.constraints.PasswordMatches;

@PasswordMatches
public class NieuweKlantForm {
	
		//private static final long serialVersionUID = 1L;

		@NotBlank
		private String voornaam;
		@NotBlank
		private String familienaam;
		
		@NotBlank
		private String straat;
		
		
		@NotBlank
		private String huisNr;
		
		@NotBlank
		@Range(min = 1000, max = 9999) 
		private String postcode;
		
		@NotBlank
		private String gemeente;
		@NotBlank
		private String gebruikersnaam;
		
		
		@NotBlank
		private String paswoord;
		
		@NotBlank
		private String verifPaswoord;
				
		

		public NieuweKlantForm() {

		}


		public NieuweKlantForm(@NotBlank String voornaam, @NotBlank String familienaam, @NotBlank String straat,
				@NotBlank String huisNr, @NotBlank @Range(min = 1000, max = 9999) String postcode,
				@NotBlank String gemeente, @NotBlank String gebruikersnaam, @NotBlank String paswoord,
				@NotBlank String verifPaswoord) {
			super();
			this.voornaam = voornaam;
			this.familienaam = familienaam;
			this.straat = straat;
			this.huisNr = huisNr;
			this.postcode = postcode;
			this.gemeente = gemeente;
			this.gebruikersnaam = gebruikersnaam;
			this.paswoord = paswoord;
			this.verifPaswoord = verifPaswoord;
		}


		public String getVoornaam() {
			return voornaam;
		}


		public String getFamilienaam() {
			return familienaam;
		}


		public String getStraat() {
			return straat;
		}


		public String getHuisNr() {
			return huisNr;
		}


		public String getPostcode() {
			return postcode;
		}


		public String getGemeente() {
			return gemeente;
		}


		public String getGebruikersnaam() {
			return gebruikersnaam;
		}


		public String getPaswoord() {
			return paswoord;
		}


		public String getVerifPaswoord() {
			return verifPaswoord;
		}


		public void setVoornaam(String voornaam) {
			this.voornaam = voornaam;
		}


		public void setFamilienaam(String familienaam) {
			this.familienaam = familienaam;
		}


		public void setStraat(String straat) {
			this.straat = straat;
		}


		public void setHuisNr(String huisNr) {
			this.huisNr = huisNr;
		}


		public void setPostcode(String postcode) {
			this.postcode = postcode;
		}


		public void setGemeente(String gemeente) {
			this.gemeente = gemeente;
		}


		public void setGebruikersnaam(String gebruikersnaam) {
			this.gebruikersnaam = gebruikersnaam;
		}


		public void setPaswoord(String paswoord) {
			this.paswoord = paswoord;
		}


		public void setVerifPaswoord(String verifPaswoord) {
			this.verifPaswoord = verifPaswoord;
		}
		
		

}