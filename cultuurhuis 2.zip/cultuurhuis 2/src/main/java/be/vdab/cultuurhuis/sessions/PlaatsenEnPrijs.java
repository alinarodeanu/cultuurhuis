/*package be.vdab.cultuurhuis.sessions;

import java.io.Serializable;
import java.math.BigDecimal;

public class PlaatsenEnPrijs implements Serializable {
	
	private static final long serialVersionUID = 1L;
		
		private final long plaatsen;
		private final BigDecimal prijs;
		
		public PlaatsenEnPrijs(long plaatsen, BigDecimal prijs) {
			this.plaatsen = plaatsen;
			this.prijs = prijs;
		}
		
		public long getPlaatsen() {
			return plaatsen;
		}

		public BigDecimal getPrijs() {
			return prijs;
		}

	}*/
	
