package be.vdab.cultuurhuis.domain;

import java.io.Serializable;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;



@Entity
@Table(name = "klanten")
public class Klant implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@NotBlank
	private String voornaam;
	
	@NotBlank
	private String familienaam;
	
	@Valid
	@Embedded
	private Adres adres;
	
	@NotBlank
	private String gebruikersnaam;
	
	public Klant(String voornaam, String familienaam, @Valid Adres adres, @NotBlank String gebruikersnaam,
			@NotBlank String paswoord) {
		
		this.voornaam = voornaam;
		this.familienaam = familienaam;
		this.adres = adres;
		this.gebruikersnaam = gebruikersnaam;
		this.paswoord = paswoord;
	}

	@NotBlank
	private String paswoord;

	
	protected Klant() {
		super();
	}

	

	public long getId() {
		return id;
	}

	public String getVoornaam() {
		return voornaam;
	}

	public String getFamilienaam() {
		return familienaam;
	}

	public Adres getAdres() {
		return adres;
	}

	public String getGebruikersnaam() {
		return gebruikersnaam;
	}

	public String getPaswoord() {
		return paswoord;
	}
	
	public Klant getKlant(){
		return this;
	}
	
	

}
