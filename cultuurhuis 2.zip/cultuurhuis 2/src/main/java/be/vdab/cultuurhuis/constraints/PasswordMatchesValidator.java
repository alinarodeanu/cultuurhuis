package be.vdab.cultuurhuis.constraints;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.passay.PasswordData;
import org.passay.PasswordValidator;
import org.passay.RuleResult;

import com.google.common.base.Joiner;

import be.vdab.cultuurhuis.forms.NieuweKlantForm;

public class PasswordMatchesValidator implements ConstraintValidator<PasswordMatches, NieuweKlantForm> {

    @Override
    public void initialize(PasswordMatches constraintAnnotation) {
    }

    @Override
    public boolean isValid(NieuweKlantForm klantForm, ConstraintValidatorContext constraintValidatorContext) {
    	/*PasswordValidator validator = new PasswordValidator((klantForm.getPaswoord()).matches(klantForm.getVerifPaswoord()));
    	
    	 RuleResult result = validator.validate(new PasswordData(klantForm.getPaswoord()));
         if (result.isValid()) {
             return true;
         }
         
         constraintValidatorContext.disableDefaultConstraintViolation();
         constraintValidatorContext.buildConstraintViolationWithTemplate(
           Joiner.on(",").join(validator.getMessages(result)))
           .addConstraintViolation();
         return false;*/
    	
    	System.out.println("***" + klantForm.getPaswoord());
    	
    	return klantForm.getPaswoord().equals(klantForm.getVerifPaswoord());
    	
     }

         
    }


  
    

