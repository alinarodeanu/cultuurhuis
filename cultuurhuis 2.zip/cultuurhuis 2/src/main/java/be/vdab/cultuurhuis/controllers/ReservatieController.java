package be.vdab.cultuurhuis.controllers;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;

import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import be.vdab.cultuurhuis.domain.Voorstelling;
import be.vdab.cultuurhuis.forms.ReserverenForm;

import be.vdab.cultuurhuis.sessions.Mandje;

@Controller
@RequestMapping("voorstellingdetail")
@SessionAttributes("reservatie")
class ReservatieController {

	private final Mandje mandje;
	// private final VoorstellingService voorstellingService;

	public ReservatieController(Mandje mandje) {
		this.mandje = mandje;
		// this.voorstellingService = voorstellingService;
	}

	@GetMapping("/{optionalVoorstelling}")
	ModelAndView goToReservatiePagina(@PathVariable Optional<Voorstelling> optionalVoorstelling) {
		Voorstelling voorstelling = optionalVoorstelling.get();

		ReserverenForm reservatie = mandje.reservatieNieuw(voorstelling);

		ModelAndView modelAndView = new ModelAndView("voorstellingdetail");

		modelAndView.addObject("reservatie", reservatie);
		modelAndView.addObject("mandjesize", mandje.getMandjeSize());

		return modelAndView;
	}

	@PostMapping("/opslaan")
	ModelAndView opslaanReservatie(@Valid @ModelAttribute("reservatie") ReserverenForm reservatie, BindingResult result,
			SessionStatus sessionStatus, Errors errors) {

		if (result.hasErrors()) {
			return new ModelAndView("voorstellingdetail", "mandjesize", mandje.getMandjeSize());
		}
		mandje.addReservatie(reservatie);
		sessionStatus.setComplete();

		return new ModelAndView("redirect:/").addObject("mandjesize", mandje.getMandjeSize());
	}

}

/*
 * @GetMapping("/{id}") public ModelAndView voorstellingDetail(@PathVariable
 * long id) {
 * 
 * /*ReserverenForm reserverenForm = new ReserverenForm();
 * if(mandje.containsId(id)) {
 * reserverenForm.setPlaatsen(mandje.getIdPlaatsen().get(id).getPlaatsen()); }*
 * 
 * ModelAndView modelAndView = new ModelAndView("voorstellingdetail");
 * //voorstellingService.findById(id).forEach(voorstelling -> //
 * modelAndView.addObject("voorstellingids", voorstelling));
 * modelAndView.addObject("voorstellingids", voorstellingService.findById(id));
 * modelAndView.addObject("vrijeplaatsen",
 * voorstellingService.findById(id).get(0).getVrijeplaatsen());
 * //modelAndView.addObject("mandjeIsLeeg", mandje.isLeeg());
 * 
 * ReserverenForm reservatie = mandje.reservatieNieuw(id);
 * 
 * modelAndView.addObject("reservatie", reservatie);
 * 
 * //modelAndView.addObject(reserverenForm);
 * 
 * return modelAndView; }
 */

/*
 * @PostMapping("/opslaan") ModelAndView opslaanReservatie(@Valid ReserverenForm
 * reserverenForm, BindingResult result, SessionStatus session){ if
 * (result.hasErrors()){ return new
 * ModelAndView("voorstellingdetail").addObject("mandjesize",
 * mandje.getMandjeSize()); } mandje.addReservatie(reserverenForm);
 * session.setComplete(); return new
 * ModelAndView("redirect:/").addObject("mandjesize", mandje.getMandjeSize()); }
 */
