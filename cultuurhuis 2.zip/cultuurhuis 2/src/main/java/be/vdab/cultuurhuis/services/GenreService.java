package be.vdab.cultuurhuis.services;

import java.util.List;

import be.vdab.cultuurhuis.domain.Genre;


public interface GenreService {

	List<Genre> findAll();
	
}
