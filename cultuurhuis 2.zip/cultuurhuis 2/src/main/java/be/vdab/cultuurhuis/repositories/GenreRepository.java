package be.vdab.cultuurhuis.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import be.vdab.cultuurhuis.domain.Genre;


public interface GenreRepository extends JpaRepository<Genre, Long> {

	List<Genre> findAll();
}
