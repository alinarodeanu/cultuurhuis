package be.vdab.cultuurhuis.controllers;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import be.vdab.cultuurhuis.domain.Adres;
import be.vdab.cultuurhuis.domain.Klant;
import be.vdab.cultuurhuis.domain.Reservatie;
import be.vdab.cultuurhuis.services.KlantService;
import be.vdab.cultuurhuis.services.ReservatieService;
import be.vdab.cultuurhuis.services.VoorstellingService;
import be.vdab.cultuurhuis.sessions.Mandje;


@RunWith(MockitoJUnitRunner.class)
public class MandjeControllerTest {
	
	private MandjeController controller;
	
	private Mandje mandje;
	
    @Mock
    private KlantService klantService;
    @Mock
    private ReservatieService reservatieService;
    @Mock
    private VoorstellingService voorstellingService;

    


    @Before
    public void before(){
       
        when(klantService.findByGebruikersnaam(any()))
                .thenReturn(Optional.of(new Klant("testnaam",
                        "testnaam",
                        new Adres("teststraat","3","3000","TestG"),
                        "testnaam","123")));

        controller = new MandjeController(mandje, voorstellingService, reservatieService, klantService);

        Map<String,List<Reservatie>> testReservaties = new HashMap<>();
        testReservaties.put("gelukt",new ArrayList<>());
        testReservaties.put("mislukt",new ArrayList<>());

        when(reservatieService.createAll(any(),any())).thenReturn(testReservaties);

    }
    

    @Test
    public void bevestigenGeeftKlantDoor(){
       
        Principal mockPrincipal = Mockito.mock(Principal.class);
        when(mockPrincipal.getName()).thenReturn("testnaam");

        assertTrue(controller.bevestigenReservaties(mockPrincipal).getModel().get("klant") instanceof Klant);

    }

   


    
    
}
